import Login from "./ui/Login";

export { Login as LoginPage };