import Register from "./ui/Register";

export { Register as RegisterPage };