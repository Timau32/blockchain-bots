export default interface ILoginForm {
    email: string;
    password: string;
}