export const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';
export const ACCESS_TOKEN = 'access_token';
export const REFRESH_TOKEN = 'refresh_token';